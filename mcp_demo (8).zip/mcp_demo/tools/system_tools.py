# tools/system_tools.py
import subprocess

def run_command(command: str) -> str:
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True,
            text=True, timeout=30, encoding="utf-8", errors="replace"
        )
        output = result.stdout.strip()
        error  = result.stderr.strip()
        if result.returncode == 0:
            return output or "（命令执行成功，无输出）"
        return f"命令出错 (code {result.returncode}):\n{error or output}"
    except subprocess.TimeoutExpired:
        return "Error: 命令执行超时（30秒）"
    except Exception as e:
        return f"Error: {str(e)}"

AVAILABLE_TOOLS = {
    "run_command": run_command,
}

TOOL_LABELS = {
    "run_command": ("⚙️", "正在执行命令"),
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "在本地执行 shell/cmd 命令，例如 python、pip、dir、ls 等",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "要执行的命令字符串"}
                },
                "required": ["command"]
            }
        }
    },
]
