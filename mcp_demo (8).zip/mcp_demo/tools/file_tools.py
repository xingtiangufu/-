# tools/file_tools.py
import os

def read_file(file_path: str) -> str:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Error: {str(e)}"

def write_file(file_path: str, content: str) -> str:
    try:
        dir_name = os.path.dirname(file_path)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Success: File '{file_path}' written."
    except Exception as e:
        return f"Error: {str(e)}"

def list_files(directory: str = ".") -> str:
    try:
        items = os.listdir(directory)
        return "\n".join(items) if items else "（目录为空）"
    except Exception as e:
        return f"Error: {str(e)}"

AVAILABLE_TOOLS = {
    "read_file":  read_file,
    "write_file": write_file,
    "list_files": list_files,
}

TOOL_LABELS = {
    "read_file":  ("📖", "正在读取文件"),
    "write_file": ("📝", "正在写入文件"),
    "list_files": ("📂", "正在列出目录"),
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "读取本地文件内容",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "文件路径，例如 test.txt"}
                },
                "required": ["file_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "创建或覆盖本地文件",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "文件路径"},
                    "content":   {"type": "string", "description": "要写入的内容"}
                },
                "required": ["file_path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "列出指定目录下的所有文件和文件夹",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory": {"type": "string", "description": "目录路径，默认为当前目录 '.'"}
                },
                "required": []
            }
        }
    },
]
