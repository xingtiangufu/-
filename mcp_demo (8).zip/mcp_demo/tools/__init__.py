# tools/__init__.py
import os, json, importlib

_config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
with open(_config_path, encoding="utf-8") as f:
    _config = json.load(f)

_enabled = _config["tools"]["enabled"]

AVAILABLE_TOOLS: dict = {}
TOOLS_DEFINITION: list = []
TOOL_LABELS: dict = {}

_MODULE_MAP = {
    "file_tools":   "file_tools",
    "system_tools": "system_tools",
    "web_tools":    "web_tools",
    "wechat_tools": "wechat_tools",
    "memory_tools": "memory_tools",
}

for module_file, config_key in _MODULE_MAP.items():
    if not _enabled.get(config_key, True):
        continue
    try:
        mod = importlib.import_module(f"tools.{module_file}")
        if hasattr(mod, "AVAILABLE_TOOLS"):  AVAILABLE_TOOLS.update(mod.AVAILABLE_TOOLS)
        if hasattr(mod, "TOOLS_DEFINITION"): TOOLS_DEFINITION.extend(mod.TOOLS_DEFINITION)
        if hasattr(mod, "TOOL_LABELS"):      TOOL_LABELS.update(mod.TOOL_LABELS)
    except Exception as e:
        print(f"[tools] 加载 {module_file} 失败: {e}")
