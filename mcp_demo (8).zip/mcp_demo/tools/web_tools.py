# tools/web_tools.py
import urllib.request
import urllib.parse
import json

def web_search(query: str) -> str:
    try:
        encoded = urllib.parse.quote(query)
        url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        parts = []
        if data.get("AbstractText"):
            parts.append(f"📖 摘要：{data['AbstractText']}")
            if data.get("AbstractURL"):
                parts.append(f"🔗 来源：{data['AbstractURL']}")
        if data.get("Answer"):
            parts.append(f"✅ 直接答案：{data['Answer']}")
        related = data.get("RelatedTopics", [])[:3]
        if related:
            parts.append("📌 相关内容：")
            for t in related:
                if isinstance(t, dict) and t.get("Text"):
                    parts.append(f"  • {t['Text'][:120]}")
        return "\n".join(parts) if parts else f"未找到关于「{query}」的直接摘要，建议换个关键词。"
    except Exception as e:
        return f"搜索出错: {str(e)}"

AVAILABLE_TOOLS = {
    "web_search": web_search,
}

TOOL_LABELS = {
    "web_search": ("🌐", "正在联网搜索"),
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "联网搜索某个关键词或问题，返回摘要信息",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "搜索关键词或问题"}
                },
                "required": ["query"]
            }
        }
    },
]
