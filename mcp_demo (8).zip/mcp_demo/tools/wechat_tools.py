# tools/wechat_tools.py
import os
import json
import subprocess
import time

# 读取配置
_cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
with open(_cfg_path, encoding="utf-8") as f:
    _cfg = json.load(f)["tools"]["wechat"]

SPECIAL_CONTACTS   = _cfg["special_contacts"]
SEARCH_X_RATIO     = _cfg["search_x_ratio"]
SEARCH_Y_RATIO     = _cfg["search_y_ratio"]
OFFSET_NORMAL      = _cfg["contact_y_offset_normal"]
OFFSET_SPECIAL     = _cfg["contact_y_offset_special"]
INPUT_Y_RATIO      = _cfg["input_y_ratio"]


def _get_wechat_win():
    try:
        import pygetwindow as gw
        wins = [w for w in gw.getAllWindows() if "微信" in w.title and w.visible]
        if not wins:
            subprocess.Popen("start weixin://", shell=True)
            time.sleep(3)
            wins = [w for w in gw.getAllWindows() if "微信" in w.title and w.visible]
        return wins[0] if wins else None
    except Exception:
        return None


def wechat_open_contact(contact: str) -> str:
    try:
        import pyautogui, pyperclip
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.4

        win = _get_wechat_win()
        if not win:
            return "FAIL:找不到微信窗口，请先手动打开微信"

        win.restore(); win.activate(); time.sleep(0.4)
        win.activate(); time.sleep(0.6)

        sx = win.left + int(win.width  * SEARCH_X_RATIO)
        sy = win.top  + int(win.height * SEARCH_Y_RATIO)

        pyautogui.click(sx, sy); time.sleep(0.5)
        pyautogui.hotkey("ctrl", "a")
        pyperclip.copy(contact)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(1.5)

        is_special = any(s in contact for s in SPECIAL_CONTACTS)

        # 尝试 OCR 精准点击
        try:
            from PIL import ImageGrab
            import pytesseract
            region = (win.left, win.top, win.left + int(win.width * 0.45), win.top + win.height)
            shot   = ImageGrab.grab(bbox=region).convert("L")
            data   = pytesseract.image_to_data(shot, lang="chi_sim",
                                               output_type=pytesseract.Output.DICT)
            for i, txt in enumerate(data["text"]):
                if contact in txt or (len(contact) > 1 and txt in contact and len(txt) > 1):
                    cx = win.left + data["left"][i] + data["width"][i] // 2
                    cy = win.top  + data["top"][i]  + data["height"][i] // 2
                    pyautogui.click(cx, cy); time.sleep(0.8)
                    return f"OK:已打开「{contact}」的聊天界面"
        except Exception:
            pass

        # 兜底：像素偏移
        offset = OFFSET_SPECIAL if is_special else OFFSET_NORMAL
        pyautogui.click(sx, sy + offset); time.sleep(0.8)
        return f"OK:已打开「{contact}」的聊天界面"

    except ImportError as e:
        return f"FAIL:缺少依赖库\n详情:{e}"
    except Exception as e:
        return f"FAIL:{str(e)}"


def wechat_fill_message(message: str) -> str:
    try:
        import pyautogui, pyperclip
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.5

        win = _get_wechat_win()
        if not win:
            return "FAIL:找不到微信窗口"

        win.restore(); win.activate(); time.sleep(0.4)
        win.activate(); time.sleep(0.5)

        cx = win.left + win.width // 2

        for ratio in [INPUT_Y_RATIO, INPUT_Y_RATIO + 0.02, INPUT_Y_RATIO - 0.03]:
            cy = win.top + int(win.height * ratio)
            pyautogui.click(cx, cy); time.sleep(0.25)

        pyautogui.hotkey("ctrl", "a"); time.sleep(0.15)
        pyperclip.copy("")
        pyautogui.hotkey("ctrl", "c"); time.sleep(0.2)
        existing = pyperclip.paste().strip()

        if existing == message.strip():
            pyautogui.hotkey("ctrl", "a"); time.sleep(0.1)
            pyautogui.press("delete");     time.sleep(0.2)

        pyperclip.copy(message)
        pyautogui.hotkey("ctrl", "a"); time.sleep(0.1)
        pyautogui.hotkey("ctrl", "v"); time.sleep(0.4)

        return f"OK:消息已填入输入框：「{message}」，请确认是否发送？"
    except ImportError as e:
        return f"FAIL:缺少依赖库\n详情:{e}"
    except Exception as e:
        return f"FAIL:{str(e)}"


def wechat_send_message() -> str:
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.3

        win = _get_wechat_win()
        if not win:
            return "FAIL:找不到微信窗口"

        win.restore(); win.activate(); time.sleep(0.4)
        win.activate(); time.sleep(0.6)

        cx = win.left + win.width  // 2
        cy = win.top  + int(win.height * INPUT_Y_RATIO)
        pyautogui.click(cx, cy); time.sleep(0.4)

        pyautogui.hotkey("ctrl", "enter"); time.sleep(0.3)
        pyautogui.press("enter");          time.sleep(0.3)
        return "OK:消息已发送！"
    except ImportError:
        return "FAIL:缺少 pyautogui"
    except Exception as e:
        return f"FAIL:{str(e)}"


AVAILABLE_TOOLS = {
    "wechat_open_contact": wechat_open_contact,
    "wechat_fill_message": wechat_fill_message,
    "wechat_send_message": wechat_send_message,
}

TOOL_LABELS = {
    "wechat_open_contact": ("💬", "正在打开微信聊天界面"),
    "wechat_fill_message": ("✏️",  "正在填写消息"),
    "wechat_send_message": ("📨", "正在发送消息"),
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "wechat_open_contact",
            "description": "第二步：用户确认联系人后调用，打开微信并进入该联系人聊天界面",
            "parameters": {
                "type": "object",
                "properties": {
                    "contact": {"type": "string", "description": "用户确认的联系人准确名字"}
                },
                "required": ["contact"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "wechat_fill_message",
            "description": "第三步：在微信聊天输入框填入消息内容但不发送，填完后询问用户是否确认发送",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {"type": "string", "description": "要填入的消息内容"}
                },
                "required": ["message"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "wechat_send_message",
            "description": "第四步：用户明确说发送/确认后才能调用，按Enter键发送微信消息",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
]
