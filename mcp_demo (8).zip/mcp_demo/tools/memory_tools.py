# tools/memory_tools.py
# ══════════════════════════════════════════════════════════════════════════════
# Memory 系统 — 完整实现
#
# 架构（对应设计图）：
#   存储层  : chat_data/memory.jsonl  每行一条记忆
#            chat_data/memory.db     SQLite FTS5 全文索引
#   记忆结构 : {id, content, chunks[], timestamp, importance(1-10), tags[]}
#   写入流程 : 内容 → 分块(512char/50overlap) → FTS5索引 → jsonl持久化
#   检索流程 : query → BM25全文 + TF-IDF语义 + 时间衰减 → 融合Rerank → top-k
#   上下文注入: client_mcp.py 在每次对话前自动调用 memory_inject_context()
#   Compaction: 对话轮次超出阈值时自动压缩历史写入记忆
# ══════════════════════════════════════════════════════════════════════════════

import os
import re
import json
import uuid
import math
import sqlite3
import threading
from datetime import datetime
from collections import Counter

# ── 路径 ──────────────────────────────────────────────────────────────────────
_BASE        = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DATA_DIR    = os.path.join(_BASE, "chat_data")
_JSONL_PATH  = os.path.join(_DATA_DIR, "memory.jsonl")
_DB_PATH     = os.path.join(_DATA_DIR, "memory.db")
os.makedirs(_DATA_DIR, exist_ok=True)

_lock = threading.Lock()   # 写操作加锁，防止并发冲突


# ══════════════════════════════════════════════════════════════════════════════
# 一、数据库初始化（FTS5 全文索引）
# ══════════════════════════════════════════════════════════════════════════════

def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(_DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    with _get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id          TEXT PRIMARY KEY,
                content     TEXT NOT NULL,
                timestamp   REAL NOT NULL,
                importance  INTEGER DEFAULT 5,
                tags        TEXT DEFAULT '[]',
                chunks_json TEXT DEFAULT '[]'
            );

            CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts
            USING fts5(
                id UNINDEXED,
                content,
                tags,
                content='memories',
                content_rowid='rowid',
                tokenize='unicode61'
            );

            CREATE TRIGGER IF NOT EXISTS memories_ai
            AFTER INSERT ON memories BEGIN
                INSERT INTO memory_fts(rowid, id, content, tags)
                VALUES (new.rowid, new.id, new.content, new.tags);
            END;

            CREATE TRIGGER IF NOT EXISTS memories_ad
            AFTER DELETE ON memories BEGIN
                INSERT INTO memory_fts(memory_fts, rowid, id, content, tags)
                VALUES ('delete', old.rowid, old.id, old.content, old.tags);
            END;

            CREATE TRIGGER IF NOT EXISTS memories_au
            AFTER UPDATE ON memories BEGIN
                INSERT INTO memory_fts(memory_fts, rowid, id, content, tags)
                VALUES ('delete', old.rowid, old.id, old.content, old.tags);
                INSERT INTO memory_fts(rowid, id, content, tags)
                VALUES (new.rowid, new.id, new.content, new.tags);
            END;
        """)


_init_db()


# ══════════════════════════════════════════════════════════════════════════════
# 二、文本分块（Chunking）— 固定大小 + 边界重叠 + 句子完整性保护
# ══════════════════════════════════════════════════════════════════════════════

def _chunk_text(text: str, chunk_size: int = 512, overlap: int = 50) -> list[str]:
    """
    按 chunk_size 字符分块，overlap 字符边界重叠。
    保护句子完整性：在句号/换行处截断，不在词中间切断。
    """
    text = text.strip()
    if len(text) <= chunk_size:
        return [text]

    # 句子分割符
    sentence_ends = re.compile(r'(?<=[。！？\n.!?])\s*')
    sentences = sentence_ends.split(text)
    sentences = [s.strip() for s in sentences if s.strip()]

    chunks, current, current_len = [], [], 0
    for sent in sentences:
        sent_len = len(sent)
        if current_len + sent_len > chunk_size and current:
            chunk_text = " ".join(current)
            chunks.append(chunk_text)
            # 保留末尾 overlap 字符作为下一块的前缀
            tail = chunk_text[-overlap:] if len(chunk_text) > overlap else chunk_text
            current = [tail]
            current_len = len(tail)
        current.append(sent)
        current_len += sent_len

    if current:
        chunks.append(" ".join(current))

    return chunks if chunks else [text]


# ══════════════════════════════════════════════════════════════════════════════
# 三、TF-IDF 语义相似度（无需外部模型）
# ══════════════════════════════════════════════════════════════════════════════

def _tokenize(text: str) -> list[str]:
    tokens = re.findall(r"[a-zA-Z0-9]+|[\u4e00-\u9fff]", text.lower())
    stopwords = {
        "的", "了", "在", "是", "我", "你", "他", "她", "它", "们",
        "和", "与", "或", "但", "也", "都", "就", "很", "有", "这",
        "那", "个", "为", "以", "上", "下", "不", "没", "已", "被",
        "a", "an", "the", "is", "are", "was", "were", "to", "of",
        "in", "on", "at", "for", "with", "by", "from", "that", "this",
    }
    return [t for t in tokens if t not in stopwords and len(t) > 0]


def _cosine_sim(vec_a: dict, vec_b: dict) -> float:
    keys = set(vec_a) & set(vec_b)
    if not keys:
        return 0.0
    dot = sum(vec_a[k] * vec_b[k] for k in keys)
    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))
    return dot / (norm_a * norm_b + 1e-9)


def _tfidf_vector(tokens: list[str], df: dict, total_docs: int) -> dict:
    if not tokens:
        return {}
    tf = Counter(tokens)
    doc_len = len(tokens)
    vec = {}
    for term, count in tf.items():
        term_tf  = count / doc_len
        term_idf = math.log((total_docs + 1) / (df.get(term, 0) + 1)) + 1.0
        vec[term] = term_tf * term_idf
    return vec


# ══════════════════════════════════════════════════════════════════════════════
# 四、JSONL 持久层
# ══════════════════════════════════════════════════════════════════════════════

def _load_jsonl() -> list[dict]:
    records = []
    if not os.path.exists(_JSONL_PATH):
        return records
    with open(_JSONL_PATH, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    return records


def _save_record_to_jsonl(record: dict):
    with open(_JSONL_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _rewrite_jsonl(records: list[dict]):
    with open(_JSONL_PATH, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


# ══════════════════════════════════════════════════════════════════════════════
# 五、核心工具函数
# ══════════════════════════════════════════════════════════════════════════════

def memory_save(
    content: str,
    importance: int = 5,
    tags: list = None,
    title: str = "",
) -> str:
    """
    将重要信息写入长期记忆。
    content    : 要记住的内容（自然语言描述）
    importance : 重要程度 1-10，默认 5
    tags       : 标签列表，如 ["用户信息", "偏好"]
    title      : 可选标题，为空时自动截取
    """
    if not content.strip():
        return "❌ 内容不能为空"

    importance = max(1, min(10, int(importance)))
    tags = tags or []
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",") if t.strip()]

    mem_id    = str(uuid.uuid4())[:8]
    timestamp = datetime.now().timestamp()
    chunks    = _chunk_text(content)

    if not title:
        first_line = content.strip().splitlines()[0]
        title = first_line[:30].strip()

    record = {
        "id":         mem_id,
        "title":      title,
        "content":    content.strip(),
        "chunks":     chunks,
        "timestamp":  timestamp,
        "importance": importance,
        "tags":       tags,
        "time_str":   datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M"),
    }

    with _lock:
        # 写 FTS5
        with _get_db() as conn:
            conn.execute(
                "INSERT INTO memories(id, content, timestamp, importance, tags, chunks_json) "
                "VALUES (?,?,?,?,?,?)",
                (mem_id, content.strip(), timestamp, importance,
                 json.dumps(tags, ensure_ascii=False),
                 json.dumps(chunks, ensure_ascii=False))
            )
        # 写 JSONL
        _save_record_to_jsonl(record)

    tag_str = " ".join(f"#{t}" for t in tags) if tags else "无标签"
    return (f"✅ 记忆已保存\n"
            f"   ID: {mem_id}\n"
            f"   标题: {title}\n"
            f"   重要度: {'★' * importance}{'☆' * (10-importance)} ({importance}/10)\n"
            f"   标签: {tag_str}\n"
            f"   分块数: {len(chunks)}")


def memory_search(query: str, top_k: int = 3) -> str:
    """
    混合检索记忆（BM25全文 + TF-IDF语义 + 时间衰减）。
    返回 top-k 条匹配记忆的摘要，含 ID 供后续 memory_get 使用。
    """
    if not query.strip():
        return "（查询词为空）"

    records = _load_jsonl()
    if not records:
        return "（记忆库为空）"

    now_ts = datetime.now().timestamp()
    query_tokens = _tokenize(query)

    # ── BM25 全文检索 ────────────────────────────────────
    fts_scores: dict[str, float] = {}
    try:
        with _get_db() as conn:
            # FTS5 rank() 返回负数，取反
            rows = conn.execute(
                "SELECT id, rank FROM memory_fts WHERE memory_fts MATCH ? ORDER BY rank LIMIT 20",
                (query,)
            ).fetchall()
            if rows:
                max_neg = max(abs(r["rank"]) for r in rows) or 1
                for r in rows:
                    fts_scores[r["id"]] = abs(r["rank"]) / max_neg
    except Exception:
        pass  # FTS5 查询失败时降级为纯语义

    # ── TF-IDF 语义相似度 ────────────────────────────────
    all_token_lists = [_tokenize(r["content"]) for r in records]
    df: dict[str, int] = {}
    for toks in all_token_lists:
        for t in set(toks):
            df[t] = df.get(t, 0) + 1
    total_docs = len(records)

    query_vec = _tfidf_vector(query_tokens, df, total_docs)
    sem_scores: dict[str, float] = {}
    max_sem = 0.0
    for i, rec in enumerate(records):
        doc_vec = _tfidf_vector(all_token_lists[i], df, total_docs)
        sim = _cosine_sim(query_vec, doc_vec)
        sem_scores[rec["id"]] = sim
        if sim > max_sem:
            max_sem = sim
    if max_sem > 0:
        sem_scores = {k: v / max_sem for k, v in sem_scores.items()}

    # ── 时间衰减（越新优先级越高）────────────────────────
    time_scores: dict[str, float] = {}
    HALF_LIFE_DAYS = 30.0
    for rec in records:
        age_days = (now_ts - rec.get("timestamp", now_ts)) / 86400
        time_scores[rec["id"]] = math.exp(-age_days / HALF_LIFE_DAYS)

    # ── 融合 Rerank（加权求和）──────────────────────────
    W_FTS, W_SEM, W_TIME, W_IMP = 0.40, 0.35, 0.15, 0.10
    all_ids = {r["id"] for r in records}
    combined: list[tuple[float, dict]] = []
    for rec in records:
        rid = rec["id"]
        score = (
            W_FTS  * fts_scores.get(rid, 0.0) +
            W_SEM  * sem_scores.get(rid, 0.0) +
            W_TIME * time_scores.get(rid, 0.0) +
            W_IMP  * (rec.get("importance", 5) / 10.0)
        )
        if score > 0.01:
            combined.append((score, rec))

    combined.sort(key=lambda x: x[0], reverse=True)
    top = combined[:top_k]

    if not top:
        return "（未找到相关记忆，可能记忆库为空或与查询无关）"

    lines = [f"🔍 记忆检索：找到 {len(combined)} 条相关，展示前 {len(top)} 条\n"]
    for rank, (score, rec) in enumerate(top, 1):
        tags_str  = " ".join(f"#{t}" for t in rec.get("tags", [])) or "无"
        snippet   = rec["content"][:180].replace("\n", " ")
        if len(rec["content"]) > 180:
            snippet += "…"
        lines.append(
            f"[{rank}] 📌 {rec.get('title', rec['id'])}\n"
            f"     ID: {rec['id']}  相关度: {score:.3f}  重要度: {rec.get('importance',5)}/10\n"
            f"     时间: {rec.get('time_str','?')}  标签: {tags_str}\n"
            f"     摘要: {snippet}\n"
        )
    return "\n".join(lines)


def memory_get(memory_id: str) -> str:
    """
    获取指定 ID 记忆的完整内容。
    memory_id: 从 memory_search 结果中获取的 ID
    """
    records = _load_jsonl()
    for rec in records:
        if rec.get("id") == memory_id:
            tags_str = " ".join(f"#{t}" for t in rec.get("tags", [])) or "无标签"
            imp      = rec.get("importance", 5)
            chunks   = rec.get("chunks", [rec["content"]])
            out = [
                f"📄 记忆详情",
                f"{'─'*40}",
                f"ID      : {rec['id']}",
                f"标题    : {rec.get('title', '无')}",
                f"时间    : {rec.get('time_str', '?')}",
                f"重要度  : {'★'*imp}{'☆'*(10-imp)} ({imp}/10)",
                f"标签    : {tags_str}",
                f"分块数  : {len(chunks)}",
                f"{'─'*40}",
                f"{rec['content']}",
            ]
            return "\n".join(out)
    return f"❌ 未找到 ID 为 {memory_id!r} 的记忆"


def memory_list(tag: str = "", min_importance: int = 1) -> str:
    """列出记忆库摘要，可按标签和最低重要度过滤。"""
    records = _load_jsonl()
    if not records:
        return "（记忆库为空）"

    if tag:
        records = [r for r in records if tag in r.get("tags", [])]
    records = [r for r in records if r.get("importance", 5) >= min_importance]

    if not records:
        return f"（没有符合条件的记忆）"

    # 按时间倒序
    records.sort(key=lambda r: r.get("timestamp", 0), reverse=True)
    lines = [f"📚 记忆库（{len(records)} 条）\n"]
    for rec in records:
        imp     = rec.get("importance", 5)
        tags_s  = " ".join(f"#{t}" for t in rec.get("tags", [])) or ""
        title   = rec.get("title", rec["content"][:20])
        lines.append(
            f"  [{imp:2d}★] {rec.get('time_str','?')}  "
            f"{title}  {tags_s}  (ID:{rec['id']})"
        )
    return "\n".join(lines)


def memory_delete(memory_id: str) -> str:
    """删除指定 ID 的记忆（同时从 FTS 和 jsonl 中移除）。"""
    records = _load_jsonl()
    new_records = [r for r in records if r.get("id") != memory_id]
    if len(new_records) == len(records):
        return f"❌ 未找到 ID 为 {memory_id!r} 的记忆"

    with _lock:
        _rewrite_jsonl(new_records)
        with _get_db() as conn:
            conn.execute("DELETE FROM memories WHERE id=?", (memory_id,))

    return f"✅ 已删除记忆 {memory_id}"


# ══════════════════════════════════════════════════════════════════════════════
# 六、上下文注入（Context Injection）— 供 client_mcp.py 调用
# ══════════════════════════════════════════════════════════════════════════════

def memory_inject_context(user_input: str, top_k: int = 3) -> str:
    """
    根据用户输入检索相关记忆，返回可注入系统上下文的字符串。
    此函数由 client_mcp.py 在每次对话前自动调用，无需 Agent 主动触发。
    返回空字符串时表示无相关记忆，不注入。
    """
    records = _load_jsonl()
    if not records:
        return ""

    now_ts       = datetime.now().timestamp()
    query_tokens = _tokenize(user_input)
    if not query_tokens:
        return ""

    all_token_lists = [_tokenize(r["content"]) for r in records]
    df: dict[str, int] = {}
    for toks in all_token_lists:
        for t in set(toks):
            df[t] = df.get(t, 0) + 1
    total_docs  = len(records)
    query_vec   = _tfidf_vector(query_tokens, df, total_docs)

    HALF_LIFE_DAYS = 30.0
    scored = []
    for i, rec in enumerate(records):
        doc_vec  = _tfidf_vector(all_token_lists[i], df, total_docs)
        sem      = _cosine_sim(query_vec, doc_vec)
        age_days = (now_ts - rec.get("timestamp", now_ts)) / 86400
        time_dec = math.exp(-age_days / HALF_LIFE_DAYS)
        imp_norm = rec.get("importance", 5) / 10.0
        score    = 0.55 * sem + 0.25 * time_dec + 0.20 * imp_norm
        if score > 0.05:
            scored.append((score, rec))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_k]
    if not top:
        return ""

    lines = ["【相关历史记忆（自动注入，供参考）】"]
    for _, rec in top:
        snippet = rec["content"][:300].replace("\n", " ")
        if len(rec["content"]) > 300:
            snippet += "…"
        lines.append(f"- [{rec.get('time_str','?')}] {snippet}")
    lines.append("【记忆注入结束】")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# 七、Compaction（对话压缩写入记忆）— 供 client_mcp.py 调用
# ══════════════════════════════════════════════════════════════════════════════

def memory_compact_session(history: list[dict], threshold: int = 20) -> bool:
    """
    当对话历史轮次超过 threshold 时触发 Compaction：
    提取对话中的重要信息写入记忆，返回 True 表示触发了压缩。
    history: conversation_history 列表
    """
    # 只统计 user/assistant 轮次
    turns = [m for m in history if m.get("role") in ("user", "assistant")]
    if len(turns) < threshold:
        return False

    # 取最近 threshold 条轮次以外的旧内容做压缩
    old_turns = turns[:-threshold]
    if not old_turns:
        return False

    # 拼合旧对话文本
    session_text_parts = []
    for m in old_turns:
        role = "用户" if m["role"] == "user" else "助手"
        content = m.get("content", "")
        if isinstance(content, list):
            content = " ".join(c.get("text", "") for c in content if isinstance(c, dict))
        if content.strip():
            session_text_parts.append(f"{role}：{content.strip()}")

    if not session_text_parts:
        return False

    session_text = "\n".join(session_text_parts)
    # 从中提取关键信息（简单启发式：找用户陈述的事实）
    user_statements = [
        line for line in session_text.splitlines()
        if line.startswith("用户：") and len(line) > 5
    ]
    if not user_statements:
        return False

    summary = "\n".join(user_statements[:10])
    memory_save(
        content=f"[Session压缩记录]\n{summary}",
        importance=4,
        tags=["session", "auto_compact"],
        title=f"Session压缩_{datetime.now().strftime('%m%d_%H%M')}",
    )
    return True


# ══════════════════════════════════════════════════════════════════════════════
# 八、工具注册
# ══════════════════════════════════════════════════════════════════════════════

AVAILABLE_TOOLS = {
    "memory_search": memory_search,
    "memory_get":    memory_get,
    "memory_save":   memory_save,
    "memory_list":   memory_list,
    "memory_delete": memory_delete,
}

TOOL_LABELS = {
    "memory_search": ("🧠", "检索长期记忆"),
    "memory_get":    ("📖", "读取记忆详情"),
    "memory_save":   ("💾", "保存新记忆"),
    "memory_list":   ("📚", "列出记忆库"),
    "memory_delete": ("🗑️",  "删除记忆"),
}

TOOLS_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "memory_search",
            "description": (
                "混合检索长期记忆（BM25全文 + 语义相似度 + 时间衰减融合排序）。"
                "触发时机：用户提到「之前」「上次」「你还记得」「我说过」，"
                "或涉及用户个人信息/偏好/历史任务时，必须先调用此工具。"
                "返回 top-k 条记忆摘要，含 ID 可用于 memory_get 获取完整内容。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "用自然语言描述要找什么记忆，如「用户的咖啡偏好」"
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "返回条数，默认3，最多5",
                        "default": 3
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_get",
            "description": (
                "获取指定记忆的完整内容。"
                "在 memory_search 返回摘要后，需要查看完整内容时调用。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {
                        "type": "string",
                        "description": "记忆ID，从 memory_search 结果的「ID:」字段获取"
                    }
                },
                "required": ["memory_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_save",
            "description": (
                "将重要信息持久化保存到长期记忆库。"
                "触发时机：用户透露个人信息/偏好/习惯、完成重要任务、有值得长期记住的结论。"
                "用第三人称记录，如「用户喜欢无糖拿铁」。"
                "importance 评分标准：10=极重要(用户身份信息), 7-9=重要(明确偏好/约定), "
                "4-6=一般(普通事件), 1-3=次要(临时信息)。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "要记住的内容，第三人称自然语言描述"
                    },
                    "importance": {
                        "type": "integer",
                        "description": "重要程度 1-10，默认5",
                        "default": 5
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "标签列表，建议从以下选择：用户信息/偏好/任务/事件/约定/技术",
                        "default": []
                    },
                    "title": {
                        "type": "string",
                        "description": "记忆标题（可留空自动生成）",
                        "default": ""
                    }
                },
                "required": ["content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_list",
            "description": "列出记忆库中的所有记忆，可按标签或最低重要度过滤。",
            "parameters": {
                "type": "object",
                "properties": {
                    "tag": {
                        "type": "string",
                        "description": "按标签过滤，留空则列出全部",
                        "default": ""
                    },
                    "min_importance": {
                        "type": "integer",
                        "description": "最低重要度过滤，默认1（全部）",
                        "default": 1
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "memory_delete",
            "description": "删除指定ID的记忆（不可恢复）。",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {
                        "type": "string",
                        "description": "要删除的记忆ID"
                    }
                },
                "required": ["memory_id"]
            }
        }
    }
]
