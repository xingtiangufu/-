# security_server.py —— 安全中间层（强化版）
# 放在 mcp_demo/ 根目录，与 app.py 同级
import os
import re
import json
import time
import threading
import unicodedata
from collections import defaultdict
from datetime import datetime

# ── 路径 ────────────────────────────────────────────────
_BASE = os.path.dirname(os.path.abspath(__file__))
_CONFIG_PATH = os.path.join(_BASE, "config.json")

# ── 加载配置 ─────────────────────────────────────────────
def _load_full_cfg() -> dict:
    with open(_CONFIG_PATH, encoding="utf-8") as f:
        return json.load(f)

_full_cfg = _load_full_cfg()
_sec_cfg = _full_cfg.get("security_server", {})
_safety_cfg = _full_cfg.get("safety", {})

# ── 运行时状态 ───────────────────────────────────────────
_state = {
    "enabled":        _sec_cfg.get("enabled", True),
    "rate_limit":     _sec_cfg.get("rate_limit",     {}).get("enabled", True),
    "content_filter": _sec_cfg.get("content_filter", {}).get("enabled", True),
    "audit_log":      _sec_cfg.get("audit_log",      {}).get("enabled", True),
}

# 速率限制
_RL_MAX    = _sec_cfg.get("rate_limit",     {}).get("max_requests",  20)
_RL_WINDOW = _sec_cfg.get("rate_limit",     {}).get("window_seconds", 60)

# 内容过滤
_CF_MAX_LEN   = _sec_cfg.get("content_filter", {}).get("max_input_length", 4000)
_CF_PATTERNS  = _sec_cfg.get("content_filter", {}).get("blocked_patterns", [])

# ── 从 safety 加载关键词（硬拦截核心词库）─────────────────
_CN_KEYWORDS   = set(_safety_cfg.get("payment_keywords", []))
_EN_KEYWORDS   = set(k.lower() for k in _safety_cfg.get("payment_keywords_en", []))
_PINYIN_KEYWORDS = set(k.lower() for k in _safety_cfg.get("payment_pinyin", []))

# ── 审计日志 ─────────────────────────────────────────────
_LOG_FILE = os.path.join(_BASE, _sec_cfg.get("audit_log", {}).get("log_file", "security_audit.log"))

_lock = threading.Lock()
_rate_buckets: dict[str, list] = defaultdict(list)
_audit_cache: list[dict] = []
_AUDIT_CACHE_MAX = 200


# ══════════════════════════════════════════════════════════
#  文本标准化 & 模糊匹配引擎
# ══════════════════════════════════════════════════════════

# 常见分隔符/装饰字符（用于拆字绕过检测）
_SEPARATOR_CHARS = re.compile(
    r'[\s·.\-_*,#|/\\~`!@#$%^&+=\[\]{}()（）：:；;，,。.、'
    r'\"\'""''「」【】《》<>♪♫☆★●○◎◆◇△▽▷=\u200b\u200c\u200d'
    r'\ufeff\u00a0\u3000]+'
)

# 全角→半角 + 大写→小写
_HALF_FULL_MAP = str.maketrans(
    'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ'
    'ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ'
    '０１２３４５６７８９',
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
)


def _normalize(text: str) -> str:
    """
    多层标准化，对抗拆字/分隔符/全角等绕过手段：
    1. 全角→半角
    2. Unicode 标准化 (NFKC)
    3. 去掉所有分隔符
    4. 连续重复字符只保留一个（如 转···账 → 转账）
    """
    text = text.translate(_HALF_FULL_MAP)
    text = unicodedata.normalize('NFKC', text)
    text = _SEPARATOR_CHARS.sub('', text)
    # 合并连续相同字符（应对 转转转→转、账账账→账 这类绕过）
    text = re.sub(r'(.)\1{2,}', r'\1', text)
    return text.lower()


def _extract_latin_runs(text: str) -> list[str]:
    """提取文本中所有连续拉丁字母串（用于拼音匹配）"""
    return re.findall(r'[a-zA-Z]+', text.lower())


def _fuzzy_match(message: str) -> tuple[bool, str]:
    """
    模糊匹配引擎，三层检测：
    1. 原文精确匹配（中文关键词 + 英文关键词）
    2. 标准化后匹配（抗分隔符、拆字、全角）
    3. 拼音匹配（抗拼音输入绕过）
    """
    msg_lower = message.lower()
    msg_norm = _normalize(message)

    # ── 第1层：原文精确匹配 ──
    for kw in _CN_KEYWORDS:
        if kw in message:
            return False, f"安全拦截：消息包含敏感词「{kw}」"
    for kw in _EN_KEYWORDS:
        if kw in msg_lower:
            return False, f"安全拦截：消息包含敏感词「{kw}」"

    # ── 第2层：标准化后匹配 ──
    # 对关键词也做标准化，然后检查
    norm_cn = {normalize_kw(kw): kw for kw in _CN_KEYWORDS}
    for norm_kw, original in norm_cn.items():
        if len(norm_kw) >= 2 and norm_kw in msg_norm:
            # 额外确认：标准化后能匹配到，说明有绕过行为
            if original not in message:
                return False, f"安全拦截：检测到变体敏感词（疑似「{original}」）"
            # 如果原文就有，第1层应该已经拦截了

    # 对英文关键词也做标准化匹配
    norm_en = {normalize_kw(kw): kw for kw in _EN_KEYWORDS}
    for norm_kw, original in norm_en.items():
        if len(norm_kw) >= 3 and norm_kw in msg_norm:
            if original not in msg_lower:
                return False, f"安全拦截：检测到变体敏感词（疑似「{original}」）"

    # ── 第3层：拼音匹配 ──
    latin_runs = _extract_latin_runs(message)
    for run in latin_runs:
        if run in _PINYIN_KEYWORDS:
            # 反查是哪个词
            pinyin_to_word = _build_pinyin_word_map()
            word = pinyin_to_word.get(run, run)
            return False, f"安全拦截：检测到拼音敏感词「{run}」（对应「{word}」）"

    # ── 第4层：数字代字检测（如 转Z账、付K款、转1账）──
    # 常见数字/字母替代表
    _SUB_PATTERNS = [
        (r'转[\s·.]*[zZ1]', '转账'),
        (r'付[\s·.]*[fF4kK]', '付款'),
        (r'收[\s·.]*[sS5]', '收款'),
        (r'红[\s·.]*[hH]', '红包'),
        (r'支[\s·.]*[zZ]', '支付'),
        (r'密[\s·.]*[mM]', '密码'),
        (r'验[\s·.]*[yY]', '验证码'),
        (r'卡[\s·.]*[kK3]', '卡号'),
    ]
    for pattern, label in _SUB_PATTERNS:
        if re.search(pattern, message):
            return False, f"安全拦截：检测到代字变体（疑似「{label}」）"

    return True, ""


def normalize_kw(kw: str) -> str:
    """对单个关键词做标准化"""
    return _normalize(kw)


_pinyin_word_map_cache = None

def _build_pinyin_word_map() -> dict:
    """构建拼音→中文词映射（缓存）"""
    global _pinyin_word_map_cache
    if _pinyin_word_map_cache is not None:
        return _pinyin_word_map_cache

    # 手动维护的拼音→词映射（只覆盖 payment_pinyin 中的关键项）
    mapping = {
        "zhuanzhang": "转账", "fukuan": "付款", "shoukuan": "收款",
        "hongbao": "红包", "zhifu": "支付", "dakuan": "打款",
        "huikuan": "汇款", "yinxingka": "银行卡", "xinyongka": "信用卡",
        "mima": "密码", "yanzhengma": "验证码", "kahao": "卡号",
        "zhanghuyue": "账户余额", "daifu": "代付", "dianfu": "垫付",
        "yufu": "预付", "weikuan": "尾款", "dingjin": "定金",
        "yajin": "押金", "shoufu": "首付", "chongzhi": "充值",
        "tixian": "提现", "cunkuan": "存款", "qukuan": "取款",
        "huabei": "花呗", "jiebei": "借呗", "baitiao": "白条",
        "fenqi": "分期", "xinda": "信贷", "wangdai": "网贷",
        "shenfenzheng": "身份证", "shoujihao": "手机号",
        "cuishou": "催收", "luodai": "裸贷", "xiaoyuandai": "校园贷",
        "xiqian": "洗钱", "feifajizi": "非法集资",
        "pangshijuankuan": "庞氏骗局", "chuanxiao": "传销",
        "sijii": "私钥", "zhujici": "助记词",
        "qianbaoaddress": "钱包地址",
        # 常见拼写错误
        "shenfenzenh": "身份证",
    }
    _pinyin_word_map_cache = mapping
    return mapping


# ══════════════════════════════════════════════════════════
#  审计日志
# ══════════════════════════════════════════════════════════

def _write_audit(identifier: str, passed: bool, reason: str, message_snippet: str = ""):
    record = {
        "time":       datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "identifier": identifier,
        "passed":     passed,
        "reason":     reason,
        "snippet":    message_snippet[:80],
    }
    with _lock:
        _audit_cache.append(record)
        if len(_audit_cache) > _AUDIT_CACHE_MAX:
            _audit_cache.pop(0)

    if _state["audit_log"]:
        try:
            with open(_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass


# ══════════════════════════════════════════════════════════
#  速率限制
# ══════════════════════════════════════════════════════════

def _check_rate_limit(identifier: str) -> tuple[bool, str]:
    now = time.time()
    with _lock:
        timestamps = _rate_buckets[identifier]
        _rate_buckets[identifier] = [t for t in timestamps if now - t < _RL_WINDOW]
        if len(_rate_buckets[identifier]) >= _RL_MAX:
            return False, f"请求过于频繁，每 {_RL_WINDOW} 秒最多 {_RL_MAX} 次，请稍后再试。"
        _rate_buckets[identifier].append(now)
    return True, ""


# ══════════════════════════════════════════════════════════
#  内容过滤（集成模糊匹配）
# ══════════════════════════════════════════════════════════

def _check_content(message: str) -> tuple[bool, str]:
    # 1. 长度限制
    if len(message) > _CF_MAX_LEN:
        return False, f"输入过长（最多 {_CF_MAX_LEN} 字），请精简后重试。"

    # 2. 自定义正则模式（blocked_patterns）
    msg_lower = message.lower()
    for pattern in _CF_PATTERNS:
        if pattern.lower() in msg_lower:
            return False, "消息包含不允许的内容，请求已拦截。"

    # 3. 关键词硬拦截 + 模糊匹配（核心防线）
    passed, reason = _fuzzy_match(message)
    if not passed:
        return False, reason

    return True, ""


# ══════════════════════════════════════════════════════════
#  对外暴露的函数
# ══════════════════════════════════════════════════════════

def security_check(message: str, identifier: str = "default") -> tuple[bool, str]:
    """
    主检查入口，app.py 在每次 /chat_stream 前调用。
    返回 (True, "") 表示放行，(False, 错误提示) 表示拦截。
    检查顺序：总开关 → 速率限制 → 内容过滤(含模糊匹配)
    """
    # 1. 总开关
    if not _state["enabled"]:
        return True, ""

    # 2. 速率限制
    if _state["rate_limit"]:
        passed, reason = _check_rate_limit(identifier)
        if not passed:
            _write_audit(identifier, False, "rate_limit", message)
            return False, reason

    # 3. 内容过滤（含关键词硬拦截 + 模糊匹配）
    if _state["content_filter"]:
        passed, reason = _check_content(message)
        if not passed:
            _write_audit(identifier, False, "content_filter|" + reason, message)
            return False, reason

    # 全部通过
    _write_audit(identifier, True, "ok", message)
    return True, ""


def get_status() -> dict:
    """返回当前安全层状态"""
    with _lock:
        return {
            "enabled":        _state["enabled"],
            "rate_limit":     _state["rate_limit"],
            "content_filter": _state["content_filter"],
            "audit_log":      _state["audit_log"],
            "config": {
                "max_requests":       _RL_MAX,
                "window_seconds":     _RL_WINDOW,
                "max_input_length":   _CF_MAX_LEN,
                "blocked_patterns":   _CF_PATTERNS,
                "cn_keywords":        len(_CN_KEYWORDS),
                "en_keywords":        len(_EN_KEYWORDS),
                "pinyin_keywords":    len(_PINYIN_KEYWORDS),
            }
        }


def get_recent_logs(n: int = 20) -> list[dict]:
    """返回最近 n 条审计记录"""
    with _lock:
        return list(_audit_cache[-n:])


def reload_config():
    """热重载配置（不重启服务即可更新关键词）"""
    global _full_cfg, _sec_cfg, _safety_cfg
    global _CN_KEYWORDS, _EN_KEYWORDS, _PINYIN_KEYWORDS
    global _pinyin_word_map_cache
    try:
        _full_cfg = _load_full_cfg()
        _sec_cfg = _full_cfg.get("security_server", {})
        _safety_cfg = _full_cfg.get("safety", {})
        _CN_KEYWORDS = set(_safety_cfg.get("payment_keywords", []))
        _EN_KEYWORDS = set(k.lower() for k in _safety_cfg.get("payment_keywords_en", []))
        _PINYIN_KEYWORDS = set(k.lower() for k in _safety_cfg.get("payment_pinyin", []))
        _pinyin_word_map_cache = None  # 清除拼音缓存
        return True
    except Exception:
        return False


# ── 各子模块开关 ─────────────────────────────────────────

def toggle_security(enabled: bool):
    with _lock:
        _state["enabled"] = enabled

def toggle_rate_limit(enabled: bool):
    with _lock:
        _state["rate_limit"] = enabled

def toggle_content_filter(enabled: bool):
    with _lock:
        _state["content_filter"] = enabled

def toggle_audit_log(enabled: bool):
    with _lock:
        _state["audit_log"] = enabled
