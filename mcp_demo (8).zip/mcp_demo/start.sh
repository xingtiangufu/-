#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  星光咖啡馆 AI 助手 — Mac/Linux 一键启动
# ═══════════════════════════════════════════════════════════════

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║       🦋 星光咖啡馆 AI 助手 · 一键启动      ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

# ── 检查 Python3 ──
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未检测到 Python3，请先安装 Python 3.9+"
    echo ""
    echo "  macOS: brew install python3"
    echo "  Ubuntu: sudo apt install python3 python3-pip python3-venv"
    exit 1
fi

# ── 检查 .env ──
if [ ! -f ".env" ]; then
    echo "[提示] 首次运行，正在创建配置文件..."
    cp .env.example .env
    echo ""
    echo "  ⚠️  请先编辑 .env 文件，填入你的 API Key ！"
    echo ""
    echo "  运行: nano .env   或   open -e .env (macOS)"
    echo "  将 API_KEY=在这里填入你的API_Key 改成你的真实 Key"
    echo "  保存后重新运行 ./start.sh"
    echo ""
    exit 0
fi

# ── 检查/安装依赖 ──
echo "[1/2] 检查依赖..."
python3 -c "import flask" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "  首次运行，正在安装依赖（可能需要几分钟）..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo ""
        echo "[错误] 依赖安装失败，请检查网络连接"
        exit 1
    fi
    echo "  ✅ 依赖安装完成！"
else
    echo "  ✅ 依赖已就绪"
fi

# ── 创建数据目录 ──
mkdir -p chat_data uploads

# ── 启动 ──
echo "[2/2] 启动服务..."
echo ""

# 尝试自动打开浏览器（静默失败）
if command -v open &> /dev/null; then
    open http://localhost:5000 2>/dev/null &
elif command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:5000 2>/dev/null &
fi

python3 app.py
