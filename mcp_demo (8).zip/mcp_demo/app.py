# ═══════════════════════════════════════════════════════════════════════════════
#  星光咖啡馆 AI 助手 — 主程序
#  启动: python app.py  →  访问 http://localhost:5000
# ═══════════════════════════════════════════════════════════════════════════════

import os
import sys
import json
import shutil
import threading
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, Response, stream_with_context

# ── 初始化 Flask ──────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder="static")

# ── 基础路径 & 数据目录 ───────────────────────────────────────────────────────
BASE       = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(BASE, "chat_data")
UPLOAD_DIR = os.path.join(BASE, "uploads")
for d in (DATA_DIR, UPLOAD_DIR):
    os.makedirs(d, exist_ok=True)

# ── 首次启动：自动从模板创建 .env ────────────────────────────────────────────
_ENV_FILE = os.path.join(BASE, ".env")
_ENV_EXAMPLE = os.path.join(BASE, ".env.example")
if not os.path.exists(_ENV_FILE) and os.path.exists(_ENV_EXAMPLE):
    shutil.copy2(_ENV_EXAMPLE, _ENV_FILE)
    print("💡 检测到首次启动，已自动创建 .env 文件")
    print("   请编辑 .env 填入你的 API Key 后重新启动！\n")
    print("=" * 50)
    with open(_ENV_FILE, "r", encoding="utf-8") as f:
        print(f.read())
    print("=" * 50)
    print("\n⬆️ 请修改上方 API_KEY 后重新运行 python app.py")
    sys.exit(0)

# ── 导入安全模块 ─────────────────────────────────────────────────────────────
from security_server import (
    security_check, get_status as get_security_status,
    get_recent_logs, reload_config as reload_security_config,
    toggle_security, toggle_rate_limit, toggle_content_filter, toggle_audit_log,
)

# ── 导入对话核心 ─────────────────────────────────────────────────────────────
from client_mcp import chat_stream, reset_conversation, cancel_current


# ═══════════════════════════════════════════════════════════════════════════════
#  配置读取
# ═══════════════════════════════════════════════════════════════════════════════

def _load_config() -> dict:
    with open(os.path.join(BASE, "config.json"), encoding="utf-8") as f:
        return json.load(f)

def _load_ui_config() -> dict:
    return _load_config()["ui"]


# ═══════════════════════════════════════════════════════════════════════════════
#  页面路由
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/config")
def config():
    """前端启动时拉取 UI 配置（仅 ui 字段，兼容旧版）"""
    return jsonify(_load_ui_config())

@app.route("/config_full")
def config_full():
    """前端启动时拉取完整配置（ui + tools + safety + security）"""
    full = _load_config()
    return jsonify({
        "ui":      full.get("ui", {}),
        "tools":   full.get("tools", {}),
        "safety":  full.get("safety", {}),
        "security": get_security_status(),
    })


# ═══════════════════════════════════════════════════════════════════════════════
#  对话流（核心路由 —— 集成安全检查）
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/chat_stream", methods=["POST"])
def chat_stream_route():
    data       = request.get_json()
    message    = data.get("message", "")
    image_b64  = data.get("image_b64")
    image_mime = data.get("image_mime")

    # ── 安全检查（集成 security_server）───────────────────
    passed, reason = security_check(message)
    if not passed:
        def blocked():
            yield json.dumps({"type": "done", "reply": f"⚠️ 安全拦截：{reason}"}, ensure_ascii=False)
        return Response(
            stream_with_context(blocked()),
            mimetype="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # ── 正常对话流 ────────────────────────────────────────
    def generate():
        try:
            for event in chat_stream(message, image_b64, image_mime):
                yield f"data: {event}\n\n"
        except GeneratorExit:
            cancel_current()

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  基础控制接口
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/cancel", methods=["POST"])
def cancel_route():
    cancel_current()
    return jsonify({"status": "cancelled"})

@app.route("/reset", methods=["POST"])
def reset():
    reset_conversation()
    return jsonify({"status": "ok"})

@app.route("/clear_data", methods=["POST"])
def clear_data():
    try:
        count = 0
        for f in os.listdir(DATA_DIR):
            fp = os.path.join(DATA_DIR, f)
            if os.path.isfile(fp):
                os.remove(fp); count += 1
            elif os.path.isdir(fp):
                shutil.rmtree(fp); count += 1
        return jsonify({"message": f"✅ 已清理 {count} 个文件/文件夹"})
    except Exception as e:
        return jsonify({"message": f"❌ 清理失败：{str(e)}"})


# ═══════════════════════════════════════════════════════════════════════════════
#  安全层管理接口
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/security/status", methods=["GET"])
def security_status():
    return jsonify(get_security_status())

@app.route("/security/reload", methods=["POST"])
def security_reload():
    ok = reload_security_config()
    return jsonify({"status": "ok" if ok else "fail", "message": "配置已热重载" if ok else "重载失败"})

@app.route("/security/logs", methods=["GET"])
def security_logs():
    n = request.args.get("n", 20, type=int)
    return jsonify({"logs": get_recent_logs(n)})

@app.route("/security/toggle", methods=["POST"])
def security_toggle():
    data = request.get_json()
    name  = data.get("name", "")
    value = data.get("value", True)
    toggle_map = {
        "security":      toggle_security,
        "rate_limit":    toggle_rate_limit,
        "content_filter": toggle_content_filter,
        "audit_log":     toggle_audit_log,
    }
    fn = toggle_map.get(name)
    if fn:
        fn(value)
        return jsonify({"status": "ok"})
    return jsonify({"status": "error", "message": f"未知开关: {name}"})


# ═══════════════════════════════════════════════════════════════════════════════
#  长期记忆管理接口
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/memory/list", methods=["GET"])
def memory_list():
    """获取所有长期记忆（JSON），供前端弹窗展示"""
    try:
        from tools.memory_tools import _load_jsonl
        records = _load_jsonl()
        records.sort(key=lambda r: r.get("timestamp", 0), reverse=True)
        items = []
        for rec in records:
            content = rec.get("content", "")
            items.append({
                "id":         rec.get("id", ""),
                "title":      rec.get("title", content[:30]),
                "content":    content,
                "time_str":   rec.get("time_str", ""),
                "importance": rec.get("importance", 5),
                "tags":       rec.get("tags", []),
            })
        return jsonify({"status": "ok", "count": len(items), "items": items})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/memory/delete", methods=["POST"])
def memory_delete():
    """删除选中的长期记忆（传入 id 列表）"""
    try:
        from tools.memory_tools import _rewrite_jsonl, _load_jsonl
        import sqlite3
        ids = request.get_json().get("ids", [])
        if not ids:
            return jsonify({"status": "error", "message": "未提供要删除的 ID"})
        records = _load_jsonl()
        id_set = set(ids)
        kept = [r for r in records if r.get("id") not in id_set]
        deleted_count = len(records) - len(kept)
        if deleted_count == 0:
            return jsonify({"status": "error", "message": "没有找到匹配的记忆"})
        _rewrite_jsonl(kept)
        db_path = os.path.join(DATA_DIR, "memory.db")
        if os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            try:
                for mid in ids:
                    conn.execute("DELETE FROM memories WHERE id=?", (mid,))
                conn.commit()
            finally:
                conn.close()
        return jsonify({"status": "ok", "deleted": deleted_count,
                         "message": f"✅ 已删除 {deleted_count} 条记忆"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route("/memory/clear", methods=["POST"])
def memory_clear():
    """清空全部长期记忆"""
    try:
        from tools.memory_tools import _rewrite_jsonl
        import sqlite3
        _rewrite_jsonl([])
        db_path = os.path.join(DATA_DIR, "memory.db")
        if os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("DELETE FROM memory_fts")
                conn.execute("DELETE FROM memories")
                conn.commit()
            finally:
                conn.close()
        return jsonify({"status": "ok", "message": "✅ 长期记忆已全部清空"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})


# ═══════════════════════════════════════════════════════════════════════════════
#  语音识别
# ═══════════════════════════════════════════════════════════════════════════════

_mic_stop_event = threading.Event()
_mic_audio_result = {}

@app.route("/mic_start", methods=["POST"])
def mic_start():
    """开始后台录音"""
    import speech_recognition as sr
    _mic_stop_event.clear()
    _mic_audio_result.clear()

    def _record():
        recognizer = sr.Recognizer()
        recognizer.energy_threshold = 300
        recognizer.dynamic_energy_threshold = True
        try:
            mic = sr.Microphone()
            with mic as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.3)
                frames = []
                import pyaudio, wave, io
                p = pyaudio.PyAudio()
                stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000,
                                input=True, frames_per_buffer=1024)
                while not _mic_stop_event.is_set():
                    data = stream.read(1024, exception_on_overflow=False)
                    frames.append(data)
                stream.stop_stream(); stream.close(); p.terminate()
                buf = io.BytesIO()
                wf = wave.open(buf, 'wb')
                wf.setnchannels(1)
                wf.setsampwidth(p.get_sample_size(pyaudio.paInt16))
                wf.setframerate(16000)
                wf.writeframes(b''.join(frames))
                wf.close(); buf.seek(0)
                with sr.AudioFile(buf) as af:
                    audio = recognizer.record(af)
                _mic_audio_result["audio"] = audio
        except Exception as e:
            _mic_audio_result["error"] = str(e)

    threading.Thread(target=_record, daemon=True).start()
    return jsonify({"status": "ok"})

@app.route("/mic_stop", methods=["POST"])
def mic_stop():
    """停止录音并用 Whisper 识别"""
    import tempfile, whisper, time
    _mic_stop_event.set()
    for _ in range(20):
        if "audio" in _mic_audio_result or "error" in _mic_audio_result:
            break
        time.sleep(0.15)
    if "error" in _mic_audio_result:
        return jsonify({"status": "error", "message": _mic_audio_result["error"]})
    if "audio" not in _mic_audio_result:
        return jsonify({"status": "error", "message": "没有录到声音，请重试"})
    audio = _mic_audio_result["audio"]
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(audio.get_wav_data())
            tmp_path = f.name
        model = whisper.load_model("small")
        result = model.transcribe(tmp_path, language="zh")
        text = result.get("text", "").strip()
        os.remove(tmp_path)
        if text:
            return jsonify({"status": "ok", "text": text})
        return jsonify({"status": "error", "message": "没有识别到内容，请重试"})
    except Exception as e:
        return jsonify({"status": "error", "message": f"识别出错：{e}"})


# ═══════════════════════════════════════════════════════════════════════════════
#  图片上传（聊天内发送图片给 AI）
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/upload_image", methods=["POST"])
def upload_image():
    file = request.files.get("image")
    if not file:
        return jsonify({"status": "error", "message": "没有收到图片"})
    import base64
    img_bytes = file.read()
    b64 = base64.b64encode(img_bytes).decode()
    mime = file.mimetype or "image/jpeg"
    return jsonify({"status": "ok", "b64": b64, "mime": mime,
                    "name": file.filename or "image.jpg"})


# ═══════════════════════════════════════════════════════════════════════════════
#  通用文件上传管理（供 AI 助手读取用户上传的文件）
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/upload", methods=["GET", "POST"])
def upload_file():
    if request.method == "GET":
        return send_from_directory("static", "upload.html")
    file = request.files.get("file")
    if not file or not file.filename:
        return jsonify({"status": "error", "message": "没有收到文件"})
    safe_name = os.path.basename(file.filename)
    save_path = os.path.join(UPLOAD_DIR, safe_name)
    counter = 1
    while os.path.exists(save_path):
        name, ext = os.path.splitext(safe_name)
        save_path = os.path.join(UPLOAD_DIR, f"{name}_{counter}{ext}")
        counter += 1
    file.save(save_path)
    meta = {"uploaded_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    meta_path = save_path + ".meta"
    with open(meta_path, "w", encoding="utf-8") as mf:
        json.dump(meta, mf, ensure_ascii=False)
    saved_name = os.path.basename(save_path)
    return jsonify({"status": "ok", "message": f"✅ 已保存：{saved_name}",
                    "name": saved_name, "path": save_path})

@app.route("/upload/list", methods=["GET"])
def upload_list():
    files = []
    for fname in os.listdir(UPLOAD_DIR):
        if fname.endswith(".meta"):
            continue
        fpath = os.path.join(UPLOAD_DIR, fname)
        if not os.path.isfile(fpath):
            continue
        size = os.path.getsize(fpath)
        mtime = os.path.getmtime(fpath)
        time_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
        meta_path = fpath + ".meta"
        if os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as mf:
                    m = json.load(mf)
                time_str = m.get("uploaded_at", time_str)
            except Exception:
                pass
        files.append({"name": fname, "path": fpath, "size": size,
                      "time_str": time_str, "mtime": mtime})
    files.sort(key=lambda f: f["mtime"], reverse=True)
    return jsonify({"files": files})

@app.route("/upload/download/<filename>")
def upload_download(filename):
    safe = os.path.basename(filename)
    return send_from_directory(UPLOAD_DIR, safe, as_attachment=True)

@app.route("/upload/delete", methods=["POST"])
def upload_delete():
    name = request.get_json().get("name", "")
    if not name:
        return jsonify({"status": "error", "message": "未指定文件名"})
    safe = os.path.basename(name)
    fpath = os.path.join(UPLOAD_DIR, safe)
    meta_path = fpath + ".meta"
    try:
        if os.path.exists(fpath):
            os.remove(fpath)
        if os.path.exists(meta_path):
            os.remove(meta_path)
        return jsonify({"status": "ok", "message": f"✅ 已删除：{safe}"})
    except Exception as e:
        return jsonify({"status": "error", "message": f"❌ 删除失败：{e}"})

@app.route("/upload/batch_delete", methods=["POST"])
def upload_batch_delete():
    names = request.get_json().get("names", [])
    if not names:
        return jsonify({"status": "error", "message": "未指定文件"})
    deleted = 0
    for name in names:
        safe = os.path.basename(name)
        fpath = os.path.join(UPLOAD_DIR, safe)
        meta_path = fpath + ".meta"
        try:
            if os.path.exists(fpath):
                os.remove(fpath); deleted += 1
            if os.path.exists(meta_path):
                os.remove(meta_path)
        except Exception:
            pass
    return jsonify({"status": "ok", "message": f"✅ 已删除 {deleted} 个文件"})


# ═══════════════════════════════════════════════════════════════════════════════
#  启动
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    cfg = _load_ui_config()
    print()
    print("  ╔══════════════════════════════════════════════╗")
    print(f"  ║  {cfg.get('icon', '🦋')}  {cfg.get('title', 'AI 助手')} · {cfg.get('subtitle', '')}  ║")
    print("  ╠══════════════════════════════════════════════╣")
    print(f"  ║  🚀 http://localhost:5000                    ║")
    print(f"  ║  📁 数据目录: chat_data/                      ║")
    print(f"  ║  📤 文件上传: http://localhost:5000/upload    ║")
    print(f"  ║  🛡️  安全层: 已激活                           ║")
    print("  ╚══════════════════════════════════════════════╝")
    print()
    app.run(debug=False, port=5000, threaded=True)
