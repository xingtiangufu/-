@echo off
chcp 65001 >nul 2>&1
title 星光咖啡馆 AI 助手

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║       🦋 星光咖啡馆 AI 助手 · 一键启动      ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ── 检查 Python ──
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.9+
    echo 下载地址: https://www.python.org/downloads/
    echo.
    echo 注意: 安装时请勾选 "Add Python to PATH"
    pause
    exit /b 1
)

:: ── 检查 .env ──
if not exist ".env" (
    echo [提示] 首次运行，正在创建配置文件...
    copy ".env.example" ".env" >nul
    echo.
    echo  ⚠️  请先编辑 .env 文件，填入你的 API Key ！
    echo.
    echo  用记事本打开 .env，将 "API_KEY=在这里填入你的API_Key"
    echo  改成你的真实 API Key，保存后重新双击 start.bat
    echo.
    start notepad .env
    pause
    exit /b 0
)

:: ── 检查 pip 依赖 ──
echo [1/2] 检查依赖...
python -c "import flask" >nul 2>&1
if errorlevel 1 (
    echo  首次运行，正在安装依赖（可能需要几分钟）...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo [错误] 依赖安装失败，请检查网络连接
        pause
        exit /b 1
    )
    echo  ✅ 依赖安装完成！
) else (
    echo  ✅ 依赖已就绪
)

:: ── 创建数据目录 ──
if not exist "chat_data" mkdir chat_data
if not exist "uploads" mkdir uploads

:: ── 启动 ──
echo [2/2] 启动服务...
echo.
start http://localhost:5000
python app.py
pause
