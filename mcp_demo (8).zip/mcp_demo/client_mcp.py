# client_mcp.py — AI 对话核心（工具调用 + 流式输出 + 长期记忆）
#
# 注意：安全检查已统一由 app.py 在请求入口处调用 security_server 模块处理，
#       本文件不再重复做支付关键词检测，专注于对话逻辑。

import os
import json
import threading
from dotenv import load_dotenv
from openai import OpenAI
import tools  # 自动从 tools/__init__.py 加载所有已启用工具

load_dotenv()

client = OpenAI(
    api_key=os.getenv("API_KEY"),
    base_url=os.getenv("BASE_URL", "https://api.openai.com/v1"),
)
MODEL = os.getenv("MODEL_NAME", "glm-4-flash")

# ── 从文件加载提示词 ────────────────────────────────────────────────────────
_BASE = os.path.dirname(os.path.abspath(__file__))

def _load_prompt() -> str:
    path = os.path.join(_BASE, "prompts", "system_prompt.md")
    with open(path, encoding="utf-8") as f:
        return f.read()

# ── 从 config.json 加载配置 ──────────────────────────────────────────────────
def _load_config() -> dict:
    path = os.path.join(_BASE, "config.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f)

_config = _load_config()

# ── 对话历史 ─────────────────────────────────────────────────────────────────
conversation_history: list = []

def _init_history():
    global conversation_history
    conversation_history = [{"role": "system", "content": _load_prompt()}]

_init_history()

# ── 取消机制 ─────────────────────────────────────────────────────────────────
_cancel_event = threading.Event()

def cancel_current():  _cancel_event.set()
def _reset_cancel():   _cancel_event.clear()
def _cancelled():      return _cancel_event.is_set()

# ── Memory 上下文注入 ────────────────────────────────────────────────────────
def _build_memory_context(user_input: str) -> str | None:
    """
    在每次对话前自动检索相关记忆，注入到 system 消息之后。
    """
    try:
        from tools.memory_tools import memory_inject_context, memory_compact_session
        # Compaction：历史过长时先压缩写入记忆
        memory_compact_session(conversation_history, threshold=20)
        # 注入上下文
        ctx = memory_inject_context(user_input, top_k=3)
        return ctx if ctx else None
    except Exception as e:
        print(f"[memory] 上下文注入失败: {e}")
        return None

# ── 主流程 ───────────────────────────────────────────────────────────────────
def chat_stream(user_input: str, image_b64: str = None, image_mime: str = None):
    """
    Generator，yield JSON 事件字符串：
      {"type": "thinking"}
      {"type": "tool_start", "name", "icon", "label", "args"}
      {"type": "tool_end",   "name", "icon", "result"}
      {"type": "done",       "reply"}
      {"type": "cancelled"}
    """
    _reset_cancel()

    # ── 构造用户消息（支持图片）──────────────────────────────────────────────
    if image_b64 and image_mime:
        user_msg = {
            "role": "user",
            "content": [
                {"type": "image_url",
                 "image_url": {"url": f"data:{image_mime};base64,{image_b64}"}},
                {"type": "text", "text": user_input or "请描述这张图片"}
            ]
        }
    else:
        user_msg = {"role": "user", "content": user_input}

    # ── Memory 上下文注入 ───────────────────────────────────────────────────
    memory_ctx = _build_memory_context(user_input)
    if memory_ctx:
        mem_injection_msg = {
            "role": "system",
            "content": memory_ctx
        }
        # 插到历史末尾（user 消息之前）
        conversation_history.append(mem_injection_msg)

    conversation_history.append(user_msg)

    yield json.dumps({"type": "thinking"}, ensure_ascii=False)

    if _cancelled():
        yield json.dumps({"type": "cancelled"}, ensure_ascii=False)
        return

    MAX_ROUNDS = 6
    for _ in range(MAX_ROUNDS):
        if _cancelled():
            yield json.dumps({"type": "cancelled"}, ensure_ascii=False)
            return

        resp = client.chat.completions.create(
            model=MODEL,
            messages=conversation_history,
            tools=tools.TOOLS_DEFINITION,
            tool_choice="auto",
        )
        msg        = resp.choices[0].message
        tool_calls = msg.tool_calls

        if not tool_calls:
            reply = msg.content
            conversation_history.append({"role": "assistant", "content": reply})
            yield json.dumps({"type": "done", "reply": reply}, ensure_ascii=False)
            return

        conversation_history.append(msg)

        for tc in tool_calls:
            if _cancelled():
                yield json.dumps({"type": "cancelled"}, ensure_ascii=False)
                return

            fn_name = tc.function.name
            fn_args = json.loads(tc.function.arguments)
            icon, label = tools.TOOL_LABELS.get(fn_name, ("🔧", f"调用 {fn_name}"))

            yield json.dumps({
                "type": "tool_start",
                "name": fn_name, "icon": icon, "label": label, "args": fn_args,
            }, ensure_ascii=False)

            if fn_name in tools.AVAILABLE_TOOLS:
                try:
                    result = tools.AVAILABLE_TOOLS[fn_name](**fn_args)
                except Exception as e:
                    result = f"工具执行出错: {e}"
            else:
                result = f"错误：找不到工具 {fn_name}"

            if _cancelled():
                yield json.dumps({"type": "cancelled"}, ensure_ascii=False)
                return

            yield json.dumps({
                "type": "tool_end",
                "name": fn_name, "icon": icon, "result": str(result)[:300],
            }, ensure_ascii=False)

            conversation_history.append({
                "role": "tool", "tool_call_id": tc.id,
                "name": fn_name, "content": str(result),
            })

    # 超出轮数，强制总结
    final = client.chat.completions.create(model=MODEL, messages=conversation_history)
    reply = final.choices[0].message.content
    conversation_history.append({"role": "assistant", "content": reply})
    yield json.dumps({"type": "done", "reply": reply}, ensure_ascii=False)


def reset_conversation():
    """清空历史，重新从文件加载提示词（支持热更新）"""
    _init_history()


# ── 命令行模式 ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("🤖 本地助手已启动！输入 'quit' 退出，'reset' 清空记忆")
    print("-" * 50)
    while True:
        user_input = input("👤 你：").strip()
        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "退出"):
            print("👋 再见！"); break
        if user_input.lower() in ("reset", "清空"):
            reset_conversation(); print("🔄 记忆已清空！"); continue
        for ev in chat_stream(user_input):
            d = json.loads(ev)
            if d["type"] == "thinking":    print("🤔 思考中...")
            elif d["type"] == "tool_start": print(f"{d['icon']} {d['label']}...")
            elif d["type"] == "tool_end":   print(f"  ✅ {str(d['result'])[:80]}")
            elif d["type"] == "done":       print(f"🤖 {d['reply']}")
        print("-" * 50)
